import { Module } from '@nestjs/common';
import { ProjectsModule } from './projects/projects.module';
import { TestimonialsModule } from './testimonials/testimonials.module';
import { ContactModule } from './contact/contact.module';
import { WorksModule } from './works/works.module';
// eslint-disable-next-line prettier/prettier
@Module({
  imports: [ProjectsModule, TestimonialsModule, ContactModule, WorksModule],
})
export class AppModule {}
