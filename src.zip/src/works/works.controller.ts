// works.controller.ts
import { Controller, Get } from '@nestjs/common';

interface WorkItem {
  id: number;
  title: string;
  category: string;
  image: string;
}

@Controller('works')
export class WorksController {
  @Get()
  findAll(): WorkItem[] {
    // In real life, fetch from a database or service.
    return [
      {
        id: 1,
        title: 'Orvillebury',
        category: 'BLUE',
        image: '/images/work1.png',
      },
      {
        id: 2,
        title: 'West Lavada',
        category: 'GREEN',
        image: '/images/work2.png',
      },
      {
        id: 3,
        title: 'Rempelshire',
        category: 'AQUA',
        image: '/images/work3.png',
      },
      {
        id: 4,
        title: 'Delfinaland',
        category: 'LIME',
        image: '/images/work4.png',
      },
      {
        id: 5,
        title: 'Buckridgeburgh',
        category: 'FUCHSIA',
        image: '/images/work5.png',
      },
      {
        id: 6,
        title: 'Pfefferstad',
        category: 'BLACK',
        image: '/images/work6.png',
      },
      {
        id: 7,
        title: 'South Adrienne',
        category: 'PURPLE',
        image: '/images/work7.png',
      },
      {
        id: 8,
        title: 'Lake Trevor',
        category: 'MAROON',
        image: '/images/work8.png',
      },
    ];
  }
}
