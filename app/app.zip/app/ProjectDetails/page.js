'use client'
import Header from '../../components/Header';
import Footer from '../../components/Footer';
import ProjectDetail from '../../components/ProjectDetails'

const Project = () => {
    return (
      <div className="bg-[#262A2C] min-h-screen text-white">
        <Header />
        <main className="py-10">
          <ProjectDetail />
        </main>
        <Footer />
      </div>
    );
  };
  
  export default Project;