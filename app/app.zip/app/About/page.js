import Header from '../../components/Header';
import Footer from '../../components/Footer';
import AboutMe from '../../components/About';

const About = () => {
    return (
      <div className="bg-[#262A2C] min-h-screen text-white">
        <Header />
        <main className="py-10">
          <AboutMe />
        </main>
        <Footer />
      </div>
    );
  };
  
  export default About;