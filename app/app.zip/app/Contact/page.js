'use client'
import Header from '../../components/Header';
import Footer from '../../components/Footer';
import Contact from '../../components/Contacts'
const Contacts = () => {
    return (
      <div className="bg-[#262A2C] min-h-screen text-white">
        <Header />
        <main className="py-10">
          <Contact />
        </main>
        <Footer />
      </div>
    );
  };
  
  export default Contacts;