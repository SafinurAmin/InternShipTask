'use client'
import Header from '../../components/Header';
import Footer from '../../components/Footer';
import WorksGallery from '../../components/WorksGallery';

const MyWorks = () => {
  return (
    <div className="bg-[#262A2C] min-h-screen text-white">
      <Header />
      <main className="py-10">
        <WorksGallery />
      </main>
      <Footer />
    </div>
  );
};

export default MyWorks;
